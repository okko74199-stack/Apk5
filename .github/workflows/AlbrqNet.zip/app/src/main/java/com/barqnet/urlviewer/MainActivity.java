package com.barqnet.urlviewer;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    
    private EditText urlInput;
    private SharedPreferences preferences;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        preferences = getSharedPreferences("BarqNetPrefs", MODE_PRIVATE);
        urlInput = findViewById(R.id.urlInput);
        Button saveButton = findViewById(R.id.saveButton);
        Button settingsButton = findViewById(R.id.settingsButton);
        
        String savedUrl = preferences.getString("saved_url", "");
        if (!savedUrl.isEmpty()) {
            openWebView(savedUrl);
        }
        
        saveButton.setOnClickListener(v -> saveUrl());
        settingsButton.setOnClickListener(v -> openSettings());
    }
    
    private void saveUrl() {
        String url = urlInput.getText().toString().trim();
        if (url.isEmpty()) {
            Toast.makeText(this, "يرجى إدخال عنوان URL", Toast.LENGTH_SHORT).show();
            return;
        }
        
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = "http://" + url;
        }
        
        preferences.edit().putString("saved_url", url).apply();
        openWebView(url);
    }
    
    private void openWebView(String url) {
        Intent intent = new Intent(this, WebViewActivity.class);
        intent.putExtra("url", url);
        startActivity(intent);
        finish();
    }
    
    private void openSettings() {
        startActivity(new Intent(this, SettingsActivity.class));
    }
}
