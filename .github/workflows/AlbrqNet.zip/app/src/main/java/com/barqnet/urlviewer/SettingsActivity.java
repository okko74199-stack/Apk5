package com.barqnet.urlviewer;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {
    
    private EditText appNameInput;
    private SharedPreferences preferences;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        
        preferences = getSharedPreferences("BarqNetPrefs", MODE_PRIVATE);
        appNameInput = findViewById(R.id.appNameInput);
        Button saveButton = findViewById(R.id.saveSettingsButton);
        Button resetButton = findViewById(R.id.resetButton);
        
        String currentAppName = preferences.getString("app_name", "استراحة البرق نت");
        appNameInput.setText(currentAppName);
        
        saveButton.setOnClickListener(v -> saveSettings());
        resetButton.setOnClickListener(v -> resetSettings());
    }
    
    private void saveSettings() {
        String appName = appNameInput.getText().toString().trim();
        if (appName.isEmpty()) {
            Toast.makeText(this, "يرجى إدخال اسم التطبيق", Toast.LENGTH_SHORT).show();
            return;
        }
        
        preferences.edit().putString("app_name", appName).apply();
        Toast.makeText(this, "تم حفظ الإعدادات", Toast.LENGTH_SHORT).show();
    }
    
    private void resetSettings() {
        preferences.edit().remove("saved_url").apply();
        Toast.makeText(this, "تم حذف الرابط المحفوظ", Toast.LENGTH_SHORT).show();
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
