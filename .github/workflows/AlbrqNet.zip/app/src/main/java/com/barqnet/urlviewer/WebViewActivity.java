package com.barqnet.urlviewer;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

public class WebViewActivity extends AppCompatActivity {
    
    private WebView webView;
    private SwipeRefreshLayout swipeRefreshLayout;
    private String currentUrl;
    
    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webview);
        
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        webView = findViewById(R.id.webView);
        
        setupWebView();
        setupPullToRefresh();
        loadUrlFromIntent();
    }
    
    private void setupWebView() {
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);
        
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                swipeRefreshLayout.setRefreshing(true);
            }
            
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                swipeRefreshLayout.setRefreshing(false);
                currentUrl = url;
            }
            
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                swipeRefreshLayout.setRefreshing(false);
                if (errorCode == WebViewClient.ERROR_CONNECT || errorCode == WebViewClient.ERROR_HOST_LOOKUP) {
                    Toast.makeText(WebViewActivity.this, "لا يمكن الوصول إلى الخادم المحلي", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(WebViewActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                }
            }
            
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (isLocalUrl(url)) {
                    view.loadUrl(url);
                } else {
                    Toast.makeText(WebViewActivity.this, "مسموح فقط بالروابط المحلية", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
        });
    }
    
    private void setupPullToRefresh() {
        swipeRefreshLayout.setOnRefreshListener(() -> {
            if (currentUrl != null && !currentUrl.isEmpty()) {
                webView.reload();
            } else {
                swipeRefreshLayout.setRefreshing(false);
            }
        });
        
        swipeRefreshLayout.setColorSchemeColors(
            getResources().getColor(R.color.primary),
            getResources().getColor(R.color.secondary),
            getResources().getColor(R.color.accent)
        );
    }
    
    private void loadUrlFromIntent() {
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("url")) {
            currentUrl = intent.getStringExtra("url");
            webView.loadUrl(currentUrl);
        }
    }
    
    private boolean isLocalUrl(String url) {
        return url.contains("192.168.") || 
               url.contains("10.0.") || 
               url.contains("172.16.") ||
               url.contains("172.17.") ||
               url.contains("localhost") ||
               url.contains("127.0.0.1");
    }
    
    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
